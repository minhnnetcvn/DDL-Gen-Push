"use client"

import { Dispatch, SetStateAction } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus, Trash2 } from "lucide-react"
import { ColumnType } from "@/types/ColumnType"
import { DatabaseConfig } from "@/types/DatabaseConfig"
import { usePostgresConfig } from "@/context/postgresContext"
import { useToast } from "@/hooks/useToast"

interface propsConfigDialogue {
	columnsConfig: ColumnType[];
	isDialogOpen: boolean;
	selectedRowId: number | null;

	setIsDialogOpen: Dispatch<SetStateAction<boolean>>;
	setcolumnsConfig: Dispatch<SetStateAction<ColumnType[]>>;

	updateQuery: (rowId: number, postgresConfig: DatabaseConfig, queryData: ColumnType[]) => Promise<boolean>;
}

export default function ConfigDialogue(props: propsConfigDialogue) {
	const { databaseConfig } = usePostgresConfig();
	const { toast } = useToast();


	const addInputRow = (type: "text" | "select" | "textarea") => {
		const newRow: ColumnType = {
			id: crypto.randomUUID(),
			key: "",
			value: "",
			dataType: type,
		}
		props.setcolumnsConfig([...props.columnsConfig, newRow])
	}

	const removeInputRow = (id: string) => {
		props.setcolumnsConfig(props.columnsConfig.filter((column) => column.id !== id))
	}

	const updateInputRowValue = (id: string, value: string) => {
		props.setcolumnsConfig(props.columnsConfig.map((column) => (column.id === id ? { ...column, value } : column)))
	}

	const updateInputRowKeyName = (id: string, newKeyName: string) => {
		props.setcolumnsConfig(props.columnsConfig.map((column) => (column.id === id ? { ...column, key: newKeyName } : column)))
	}

	async function handleDialogSave() {
		if (props.selectedRowId == null) {
			toast({
				title: "No row selected",
				description: "Open a row from the results table before saving.",
				variant: "destructive",
			});
			return;
		}

		const ok = await props.updateQuery(props.selectedRowId, databaseConfig, props.columnsConfig);
		if (ok) {
			props.setIsDialogOpen(false);
		}
	}

	return (
		<Dialog open={props.isDialogOpen} onOpenChange={props.setIsDialogOpen}>
			<DialogContent className="w-[90vw] h-[90vh] overflow-hidden flex flex-col max-w-none max-h-none">
				<DialogHeader>
					<DialogTitle>
						Edit Row Configuration
						{props.selectedRowId != null ? ` (ID: ${props.selectedRowId})` : ""}
					</DialogTitle>
					<DialogDescription>
						Customize your input fields below. Click the add buttons to create new rows.
					</DialogDescription>
				</DialogHeader>

				<div className="flex-1 overflow-y-auto space-y-4 pr-4">
					{props.columnsConfig.map((column) => (
						<Card key={column.id} className="p-4">
							<div className="flex items-start gap-4">
								<div className="flex-1 space-y-3">
									<div className="flex items-center gap-2">
										<Label htmlFor={`column-name-${column.id}`} className="min-w-[80px]">
											Column Name:
										</Label>
										<Input
											id={`column-name-${column.id}`}
											value={column.key}
											onChange={(e) => updateInputRowKeyName(column.id, e.target.value)}
											className="flex-1"
										/>
									</div>

									<div className="space-y-2">
										{column.dataType === "text" && (
											<Input
												id={`column-value-${column.id}`}
												value={column.value}
												onChange={(e) => updateInputRowValue(column.id, e.target.value)}
												placeholder="Enter text..."
											/>
										)}
										{column.dataType === "select" && (
											<Select value={column.value} onValueChange={(v) => updateInputRowValue(column.id, v)}>
												<SelectTrigger id={`input-${column.id}`}>
													<SelectValue placeholder="Select an option" />
												</SelectTrigger>
												<SelectContent>
													{column.options?.map((option) => (
														<SelectItem key={option} value={option}>
															{option}
														</SelectItem>
													))}
												</SelectContent>
											</Select>
										)}
										{column.dataType === "textarea" && (
											<Textarea
												id={`input-${column.id}`}
												value={column.value}
												onChange={(e) => updateInputRowValue(column.id, e.target.value)}
												placeholder="Enter multi-line text..."
												rows={4}
											/>
										)}
									</div>
								</div>

								<Button
									variant="ghost"
									size="icon"
									onClick={() => removeInputRow(column.id)}
									className="text-destructive hover:text-destructive"
								>
									<Trash2 className="h-4 w-4" />
								</Button>
							</div>
						</Card>
					))}
				</div>

				<div className="border-t pt-4 space-y-4">
					<div className="flex flex-wrap gap-2">
						<Button className="cursor-pointer" type="button" variant="outline" size="sm" onClick={() => addInputRow("text")}>
							<Plus className="h-4 w-4 mr-2" />
							Add Text Input
						</Button>
						<Button type="button" variant="outline" className="cursor-pointer" size="sm" onClick={() => addInputRow("textarea")}>
							<Plus className="h-4 w-4 mr-2" />
							Add Textarea
						</Button>
					</div>

					<div className="flex justify-end gap-2">
						<Button variant="outline" onClick={() => props.setIsDialogOpen(false)}>
							Cancel
						</Button>
						<Button type="button" onClick={() => void handleDialogSave()}>
							Save Configuration
						</Button>
					</div>
				</div>
			</DialogContent>
		</Dialog>
	)
}